// SPDX-FileCopyrightText: Copyright 2024 shadPS4 Emulator Project
// SPDX-License-Identifier: GPL-2.0-or-later

#pragma once

#include <cstdlib>

#include <chrono>
#include <condition_variable>
#include <deque>
#include <memory>
#include <coroutine>
#include <exception>
#include <mutex>
#include <semaphore>
#include <span>
#include <thread>
#include <vector>
#include <queue>

#include "common/assert.h"
#include "common/slot_vector.h"
#include "common/types.h"
#include "common/unique_function.h"
#include "bbport_clobber.h"
#include "video_core/amdgpu/cb_db_extent.h"
#include "video_core/amdgpu/regs.h"

namespace Vulkan {
class Rasterizer;
}

namespace Libraries::VideoOut {
struct VideoOutPort;
}

namespace Libraries::GnmDriver {
bool SubmitLockOnDecode(); // gnmdriver.cpp
}

namespace AmdGpu {

union PM4Header;

struct Liverpool {
    static constexpr u32 GfxQueueId = 0u;
    static constexpr u32 NumGfxRings = 1u;     // actually 2, but HP is reserved by system software
    static constexpr u32 NumComputePipes = 7u; // actually 8, but #7 is reserved by system software
    static constexpr u32 NumQueuesPerPipe = 8u;
    static constexpr u32 NumComputeRings = NumComputePipes * NumQueuesPerPipe;
    static constexpr u32 NumTotalQueues = NumGfxRings + NumComputeRings;
    static_assert(NumTotalQueues < 64u); // need to fit into u64 bitmap for ffs

    enum ContextRegs : u32 {
        DbZInfo = 0xA010,
        CbColor0Base = 0xA318,
        CbColor1Base = 0xA327,
        CbColor2Base = 0xA336,
        CbColor3Base = 0xA345,
        CbColor4Base = 0xA354,
        CbColor5Base = 0xA363,
        CbColor6Base = 0xA372,
        CbColor7Base = 0xA381,
        CbColor0Cmask = 0xA31F,
        CbColor1Cmask = 0xA32E,
        CbColor2Cmask = 0xA33D,
        CbColor3Cmask = 0xA34C,
        CbColor4Cmask = 0xA35B,
        CbColor5Cmask = 0xA36A,
        CbColor6Cmask = 0xA379,
        CbColor7Cmask = 0xA388,
    };

    Regs regs{};
    std::array<CbDbExtent, NUM_COLOR_BUFFERS> last_cb_extent{};
    CbDbExtent last_db_extent{};
    /// bbport: register blocks written since the last draw handed to the draw recording thread
    /// (Rasterizer::PostDraw sends them along).
    RegDirty pipe_dirty;
    /// bbport: fence writes handed to the draw recording thread and not yet done there: a
    /// WaitRegMem on one of them is met in stream order without waiting for that thread.
    struct PendingFence {
        VAddr address;
        u64 data;
        u32 num_bytes;
        u64 position;
    };
    std::deque<PendingFence> pending_fences;
    void NotePendingFences(const auto& event);
    bool PendingFenceValue(VAddr address, u32& value);
    void NotePendingWrite(const struct PM4CmdWriteData& write_data, u32 num_bytes);
    /// bbport: running checksum of graphics-register packets (see ApplyGraphicsRegisterPacket).
    u64 gfx_reg_checksum{};
    /// Top-level graphics submissions, numbered for the draw preparation workers.
    static constexpr u64 NoSeq = ~0ull;
    u64 gfx_submit_seq{};
    static u64 HashRegisterPacket(u64 checksum, const u32* words, u32 count);
    /// `dirty` (draw-preparation scanner) records the register blocks written.
    static void ApplyGraphicsRegisterPacket(Regs& regs, const PM4Header* header, u64& checksum,
                                            RegDirty* dirty = nullptr);

public:
    explicit Liverpool();
    ~Liverpool();

    void SubmitGfx(std::span<const u32> dcb, std::span<const u32> ccb);
    void SubmitAsc(u32 gnm_vqid, std::span<const u32> acb);

    /// `frame` (BB_SUBMIT_LOCK=frame): the guest's frame number, reported finished once the GPU
    /// has executed what was submitted until now on every queue, compute queues too (the game
    /// reuses the frame's memory then; the submission lock waited for all of them as well)
    /// (Libraries::GnmDriver::NoteFramesRetired).
    void SubmitDone(u64 frame = 0) noexcept {
        std::scoped_lock lk{submit_mutex};
        if (frame != 0) {
            frame_ends.emplace_back(submissions_total, frame);
        }
        mapped_queues[GfxQueueId].ccb_buffer_offset = 0;
        mapped_queues[GfxQueueId].dcb_buffer_offset = 0;
        submit_done = true;
        submit_cv.notify_one();
    }

    void WaitGpuIdle() noexcept {
        std::unique_lock lk{submit_mutex};
        submit_cv.wait(lk, [this] { return num_submits == 0; });
    }

    /// bbport: also the draw recording thread and the fences it deferred are done (see
    /// work_retired). sceGnmSubmitDone does not block the guest when this is true.
    bool IsGpuIdle() const {
        static const bool use_retired = [] {
            const char* env = std::getenv("BB_WORK_RETIRED");
            return !(env && env[0] == '0');
        }();
        // BB_SUBMIT_LOCK=decode with honest labels: decoded is enough.
        return num_submits == 0 &&
               (work_retired || !use_retired || Libraries::GnmDriver::SubmitLockOnDecode());
    }

    void SetVoPort(Libraries::VideoOut::VideoOutPort* port) {
        vo_port = port;
    }

    void BindRasterizer(Vulkan::Rasterizer* rasterizer_) {
        rasterizer = rasterizer_;
    }

    template <bool wait_done = false>
    void SendCommand(auto&& func) {
        if constexpr (wait_done) {
            std::binary_semaphore sem{0};
            {
                std::scoped_lock lk{submit_mutex};
                command_queue.emplace([&sem, &func] {
                    func();
                    sem.release();
                });
                ++num_commands;
                submit_cv.notify_one();
            }
            sem.acquire();
        } else {
            std::scoped_lock lk{submit_mutex};
            command_queue.emplace(std::move(func));
            ++num_commands;
            submit_cv.notify_one();
        }
    }

    void ReserveCopyBufferSpace() {
        GpuQueue& gfx_queue = mapped_queues[GfxQueueId];
        std::scoped_lock lk(gfx_queue.m_access);
        constexpr size_t GfxReservedSize = 2_MB >> 2;
        gfx_queue.ccb_buffer.reserve(GfxReservedSize);
        gfx_queue.dcb_buffer.reserve(GfxReservedSize);
    }

    inline ComputeProgram& GetCsRegs() {
        return mapped_queues[curr_qid].cs_state;
    }

    struct AscQueueInfo {
        static constexpr size_t Pm4BufferSize = 1024;
        VAddr map_addr;
        u32* read_addr;
        u32 ring_size_dw;
        u32 pipe_id;
        std::array<u32, Pm4BufferSize> tmp_packet;
        u32 tmp_dwords;
    };
    Common::SlotVector<AscQueueInfo> asc_queues{};

    std::thread::id GetGpuCommandProcessorThread() {
        return gpu_id;
    }

#if defined(__linux__) || defined(_WIN32)
    u32 GetGpuCommandProcessorThreadId() {
        return gpu_tid;
    }
#endif

private:
    struct Task {
        struct promise_type {
            auto get_return_object() {
                Task task{};
                task.handle = std::coroutine_handle<promise_type>::from_promise(*this);
                return task;
            }
            static constexpr std::suspend_always initial_suspend() noexcept {
                // We want the task to be suspended at start
                return {};
            }
            static constexpr std::suspend_always final_suspend() noexcept {
                return {};
            }
            void unhandled_exception() {
                try {
                    std::rethrow_exception(std::current_exception());
                } catch (const std::exception& e) {
                    UNREACHABLE_MSG("Unhandled exception: {}", e.what());
                }
            }
            void return_void() {}
            struct empty {};
            std::suspend_always yield_value(empty&&) {
                return {};
            }
        };

        using Handle = std::coroutine_handle<promise_type>;
        Handle handle;
    };

    using CmdBuffer = std::pair<std::span<const u32>, std::span<const u32>>;
    CmdBuffer CopyCmdBuffers(std::span<const u32> dcb, std::span<const u32> ccb);
    /// bbport: a submission's command buffers copied when the guest submits them
    /// (BB_COPY_GPU_BUFFERS): the guest reused their memory before the GPU thread decoded
    /// them ("PM4 type 0" from zeros or the next frame's commands, while an area loads).
    /// SacredFire issue #2: the copy's storage comes from BbClobber (whole, page-aligned pages
    /// with BB_COPY_PROTECT=1, so that the copy can be read-only while it is decoded).
    template <typename T>
    struct CopyAllocator {
        using value_type = T;
        CopyAllocator() = default;
        template <typename U>
        CopyAllocator(const CopyAllocator<U>&) {}
        T* allocate(std::size_t n) {
            return static_cast<T*>(BbClobber::AllocCopy(n * sizeof(T)));
        }
        void deallocate(T* p, std::size_t n) noexcept {
            BbClobber::FreeCopy(p, n * sizeof(T));
        }
        bool operator==(const CopyAllocator&) const {
            return true;
        }
    };
    struct SubmittedCopy {
        std::vector<u32, CopyAllocator<u32>> data; ///< dcb, then ccb
        const u32* guest_dcb{};
        std::size_t dcb_dwords{};
        const u32* guest_ccb{};
        std::size_t ccb_dwords{};
        std::chrono::steady_clock::time_point submitted;
        /// issue #2: dword offset of the first non-packet dword of the dcb (-1: none) right after
        /// the copy was made, and again when the GPU thread starts decoding it.
        s64 bad_at_submit = -1;
        s64 bad_at_decode = -1;
    };
    Task ProcessGraphics(std::span<const u32> dcb, std::span<const u32> ccb, u64 seq = NoSeq,
                         std::shared_ptr<SubmittedCopy> copy = {});
    /// After a copied submission is decoded: whether the guest changed its command buffers since.
    static void CheckSubmittedCopy(const SubmittedCopy& copy, u64 seq);
    Task ProcessCeUpdate(std::span<const u32> ccb);
    template <bool is_indirect = false>
    Task ProcessCompute(std::span<const u32> acb, u32 vqid);

    void ProcessCommands();
    void Process(std::stop_token stoken);

    struct GpuQueue {
        std::mutex m_access{};
        std::atomic<u32> dcb_buffer_offset;
        std::atomic<u32> ccb_buffer_offset;
        std::vector<u32> dcb_buffer;
        std::vector<u32> ccb_buffer;
        std::queue<Task::Handle> submits{};
        ComputeProgram cs_state{};
    };
    std::array<GpuQueue, NumTotalQueues> mapped_queues{};
    u32 num_mapped_queues{1u}; // GFX is always available

    VAddr indirect_args_addr{};
    u32 num_counter_pairs{};
    u64 pixel_counter{};

    struct ConstantEngine {
        void Reset() {
            ce_count = 0;
            de_count = 0;
            ce_compare_count = 0;
        }

        [[nodiscard]] u32 Diff() const {
            ASSERT_MSG(ce_count >= de_count, "DE counter is ahead of CE");
            return ce_count - de_count;
        }

        u32 ce_compare_count{};
        u32 ce_count{};
        u32 de_count{};
        static std::array<u8, 48_KB> constants_heap;
    } cblock{};

    Vulkan::Rasterizer* rasterizer{};
    Libraries::VideoOut::VideoOutPort* vo_port{};
    const bool guest_markers_enabled;
    std::jthread process_thread{};
    std::atomic<u32> num_submits{};
    /// BB_SUBMIT_LOCK=decode, under submit_mutex: graphics submissions made and decoded, and per frame
    /// sceGnmSubmitDone ended the graphics submissions made so far (count, frame number).
    u64 gfx_submitted = 0, gfx_decoded = 0;
    u64 decoded_total = 0; ///< submissions of every queue decoded (submissions_total)
    void* last_decoded = nullptr; ///< BB_TIMELINE: the submission whose decoding began last
    std::deque<std::pair<u64, u64>> frame_ends;
    /// Frames whose graphics submissions are all decoded are reported finished once the GPU has
    /// executed the work recorded so far (GPU command thread).
    void SignalDecodedFrames();
    /// BB_HONEST_LABELS: GPU idle once the GPU has finished the work up to `generation` and nothing
    /// was submitted since (the interrupt, work_retired).
    void SignalGpuIdle(u64 generation);
    /// bbport: false from a submission until its draws and deferred fences are done (stage A
    /// decrements num_submits once it has decoded a submission, before that). Under
    /// submit_mutex with num_submits.
    std::atomic<bool> work_retired{true};
    /// bbport: submissions so far (submit_mutex): BB_HONEST_LABELS GPU idle checks none came since.
    u64 submissions_total = 0;
    std::atomic<u32> num_commands{};
    std::atomic<bool> submit_done{};
    std::mutex submit_mutex;
    std::condition_variable_any submit_cv;
    std::queue<Common::UniqueFunction<void>> command_queue{};
    std::thread::id gpu_id;
#if defined(__linux__) || defined(_WIN32)
    u32 gpu_tid{};
#endif
    s32 curr_qid{-1};
};

} // namespace AmdGpu
